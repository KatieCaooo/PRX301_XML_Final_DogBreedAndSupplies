/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import java.io.FileInputStream;

/**
 *
 * @author Toan
 */
public class TestWellFormed {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String file = "D:\\CodeXML\\Test_Project\\web\\WEB-INF\\dirtycoins.xml";
        //String file = "D:\\CodeXML\\Test_Project\\web\\test.xml";
        WellFormer former = new WellFormer();
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(file);
            former.createWellFormedXML(fis, "D:\\CodeXML\\Test_Project\\web\\wellformedFile.xml");
            
        } catch (Exception e) {

        } finally {
            try {
                if (fis != null) {
                    fis.close();
                }
            } catch (Exception e) {
            }
        }
    }

}
